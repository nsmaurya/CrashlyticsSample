//
//  ViewController.m
//  CrashlyticsSample
//
//  Created by Bhavna_Puri on 6/17/15.
//  Copyright (c) 2015 Sunil Maurya. All rights reserved.
//

#import "ViewController.h"
#import <Crashlytics/Crashlytics.h>
@interface ViewController ()
- (IBAction)btnCaughtClick:(id)sender;
- (IBAction)btnUncaughtClick:(id)sender;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //for sending just crash
    //[[Crashlytics sharedInstance] crash];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)btnCaughtClick:(id)sender {
    
    @try {
        [self exceptionGenerator];
    }
    @catch (NSException *exception) {
        
        NSLog(@"%@",exception);
    }
    
}

- (IBAction)btnUncaughtClick:(id)sender {
    
    [self exceptionGenerator];
    
}

-(void) exceptionGenerator
{
    NSMutableDictionary *dict = [[NSMutableDictionary alloc] init];
    [dict setObject:nil forKey:@"1"];//can't assign nil using setObject: method
}
@end
